package com.example.placeApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlaceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlaceApiApplication.class, args);
	}

}
